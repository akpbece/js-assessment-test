(function() {
	'use strict';
	angular.module('core.localeService', ['core.bundle']);
})();
