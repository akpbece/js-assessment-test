(function() {
	'use strict';

	angular.module('core.bundle', [
		'core.logger'
	]);

})();
