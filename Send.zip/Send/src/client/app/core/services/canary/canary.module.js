(function() {
	'use strict';

	angular.module('core.canary' , [
		'core.logger'
	]);

})();
