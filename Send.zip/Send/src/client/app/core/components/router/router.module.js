(function() {
	'use strict';

	angular.module('core.components.router', [
		'ui.router',
		'core.logger'
	]);
})();
