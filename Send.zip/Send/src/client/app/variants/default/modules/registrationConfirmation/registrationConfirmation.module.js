(function() {
	'use strict';

	angular.module('registrationConfirmation', [
			'app.core'
		]);
})();
