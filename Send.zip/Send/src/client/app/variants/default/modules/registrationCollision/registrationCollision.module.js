(function() {
	'use strict';

	angular.module('registrationCollision', [
		'app.core'
	]);
})();
