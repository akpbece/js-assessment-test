(function() {
	'use strict';

	angular.module('verifyUserAuth', [
		'app.core'
	]);

})();
