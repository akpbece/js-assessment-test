(function() {
	'use strict';

	angular.module('shippingAddress', [
		'app.core'
	]);

})();
