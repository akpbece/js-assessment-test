/**
 * @module Sign In
 * @description This module will manage wallet sign in.
 */
(function() {
	'use strict';

	angular.module('signin', [
		'app.core'
	]);

})();
