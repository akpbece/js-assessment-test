/**
 * @module Terms & Condition
 * @description This module will manage wallet T&C.
 */
(function() {
	'use strict';

	angular.module('verifyForgotPassword', [
		'app.core'
	]);

})();
