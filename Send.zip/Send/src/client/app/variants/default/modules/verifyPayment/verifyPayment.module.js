(function() {
	'use strict';

	angular.module('verifyPayment', [
		'app.core'
	]);

})();
