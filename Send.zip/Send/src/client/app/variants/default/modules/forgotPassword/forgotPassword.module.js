/**
 * @module Forgot Password
 * @description This module will manage wallet Forgot Password.
 */
(function() {
	'use strict';

	angular.module('forgotPassword', [
		'app.core'
	]);

})();
