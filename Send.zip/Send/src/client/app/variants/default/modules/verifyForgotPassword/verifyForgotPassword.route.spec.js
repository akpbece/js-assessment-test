/* jshint -W117 */
describe('Verify Forgot Password routes', function() {
	//describe('state', function() {
	//	var view = 'app/modules/terms/terms.html';
    //
	//	beforeEach(function() {
	//		module('terms');
	//		bard.inject('$rootScope', '$state', '$templateCache');
	//	});
    //
	//	beforeEach(function() {
	//		$templateCache.put(view, '');
	//	});
    //
	//	it('should map state terms to url /terms ', function() {
	//		expect($state.href('terms', {})).to.equal('/terms');
	//	});
    //
	//	it('should map /terms route to terms View template', function() {
	//		expect($state.get('terms').templateUrl).to.equal(view);
	//	});
    //
	//	it('of terms should work with $state.go', function() {
	//		$state.go('terms');
	//		$rootScope.$apply();
	//		expect($state.is('terms'));
	//	});
	//});
});
