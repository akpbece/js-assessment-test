(function() {
	'use strict';

	angular.module('resetForgotPassword', [
		'app.core'
	]);

})();
