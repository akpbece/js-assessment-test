(function() {
	'use strict';

	angular.module('userInformation', [
		'app.core'
	]);

})();
