(function() {
	'use strict';

	angular.module('app.directives', []);
})();
