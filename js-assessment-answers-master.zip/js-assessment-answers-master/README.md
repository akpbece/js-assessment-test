# JS Assessment Answers

This repo contains the answers to the tests in the [js-assessment](https://github.com/rmurphey/js-assessment) repo. See the README there for instructions on how to work on these tests.