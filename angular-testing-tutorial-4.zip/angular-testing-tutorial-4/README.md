# Testing AngularJS With Protractor and Karma

Welcome, friends!

### Blog Posts

- [Part 1](http://mherman.org/blog/2015/04/09/testing-angularjs-with-protractor-and-karma-part-1/#.VSa5MpPF88Y) - In the first part we’ll look at unit tests, which ensure that small, isolated pieces of code (e.g., a unit) behave as expected.